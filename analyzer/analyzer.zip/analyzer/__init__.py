from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager

app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
CONSUMER_KEY = "xOHr0Eorj1N3bRWj2JfiF9gKS"
CONSUMER_SECRET = "VJQT0YLDVfiWtiq9CS2hb0Taw8ZO7dRSxnBIvZNogAVOlZ3wfj"
ACCESS_TOKEN = "286123517-zfIF4wvfhyrwUObNmwljtoTcwT6Bf4RZF7f3Wadp"
ACCESS_SECRET = "lPjtJVb0Z0hTWEc4bdjQaKpinHBoXFWAKBTL8KVkBEE3B"
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

from analyzer import routes
