from tensorflow import keras
from keras.preprocessing.sequence import pad_sequences
import pickle
import re
import numpy as np
import os
from collections import Counter
import logging
import time
import pickle
import itertools

def decode_sentiment(score, include_neutral=True):
        SENTIMENT_THRESHOLDS=(0.2,0.7)
        label = ['Negative','Positive','Neutral']
        if include_neutral:
            if score <= SENTIMENT_THRESHOLDS[0]:
                label = label[0]
                return label
            elif score >= SENTIMENT_THRESHOLDS[1]:
                label = label[1]
                return label
            else:
                return label[2]

class TweetClassifier:

    def __init__(self):
        self.model = keras.models.load_model('model.h5')
        self.tokenizer=pickle.load(open("tokenizer.pkl",'rb'))
        self.MAX_SEQUENCE_LENGTH = 30


    def predict(self, text, include_neutral=True):
        start_at = time.time()
        x_text = pad_sequences(self.tokenizer.texts_to_sequences([text]), maxlen=self.MAX_SEQUENCE_LENGTH)
        score = self.model.predict([x_text][0])
        label = decode_sentiment(score, include_neutral=include_neutral)

        return {"label": label, "score": float(score),
        "elapsed_time": time.time()-start_at}

        