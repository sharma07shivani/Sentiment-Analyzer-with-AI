from flask import render_template, url_for, flash, redirect, request
from analyzer import app, db, bcrypt
from analyzer import CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, ACCESS_SECRET
from analyzer.forms import RegistrationForm, LoginForm
from analyzer.models import User, Hashtag, Tweet, Homepagedata
from flask_login import login_user, current_user, logout_user, login_required
from sqlalchemy import exc
import sqlite3
import tweepy
from analyzer.Tweet_processing_prediction import TweetClassifier

#globally defined to be used in every function
user=[]
tweets=[]
likes=[]
time=[]
predictions=[]
sentiment_tweet = []
count_positive=0
count_negative=0
count_neutral=0

@app.route("/", methods = ['GET','POST'])
@app.route("/home", methods = ['GET','POST'])
def home():
    if request.method=="POST":
        Name = request.form['name']
        Email = request.form['email']
        Subject = request.form['subject']
        query = Homepagedata(Name=Name, Email=Email, Subject=Subject)
        try:
            db.session.add(query)
            db.session.commit()
        except:
            db.session.rollback()
            flash("Error", 'danger')
    return render_template('Home.html')

#----------->User Account Starts<---------------
@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)



@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))


@app.route("/account")
@login_required
def account():
    return render_template('account.html', title='Account')
#------->User Acoount End<---------


#Authenticating twitter Api
def authenticate():
    auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN,ACCESS_SECRET)
    api = tweepy.API(auth)
    return api

#Section from hashtag routes
@app.route('/hashtag', methods = ['GET','POST'])
def dashboard():
    api=authenticate()
    if request.method=='POST':

        #Fetching Hashtag to analyze
        Tweet = request.form['liveTweet']

        #emptying lists from every request of hashtag
        del user[:]
        del tweets[:]
        del likes[:]
        del sentiment_tweet[:]


        #Twitter Crawling for live data
        for tweet in tweepy.Cursor(api.search, q = Tweet+' -filter:retweets', lang="en", tweet_mode="extended").items(100):
            user.append(tweet.user.screen_name)
            tweets.append(tweet.full_text)
            likes.append(tweet.favorite_count)
            time.append(tweet.created_at)

        #Counting number of likes, postive and negative tweets
        Number_of_likes = sum(likes)

        #Adding hashtag to database
        new_data = Hashtag(hashtag=Tweet)
        
        db.session.add(new_data)
        db.session.commit()

        #using the model
        obj = TweetClassifier()
        predictions = map(obj.predict, tweets)
        global count_negative
        global count_positive
        global count_neutral 
        # reinitializing at every request
        count_negative = 0
        count_positive = 0
        count_neutral = 0
        for i in predictions:
            sentiment_tweet.append(i['label'])
            if i['label']=='Negative':
                count_negative+=1
            elif i['label']=='Positive':
                count_positive+=1
            else:
                count_neutral+=1

        

        
        return render_template("index.html",number=200, likes = Number_of_likes, negative = count_negative, positive=count_positive, neutral=count_neutral)


    return render_template("index.html")

@app.route('/charts', methods = ['GET','POST'])
def charts():
    return render_template('charts.html', positive=count_positive, negative=count_negative, neutral=count_neutral)

@app.route('/tables', methods=['GET','POST'])
def toptweets():

    return render_template('tables.html', user=user, tweets=tweets,likes= likes,predictions=sentiment_tweet)

@app.route('/hashtag/all', methods=['GET'])
def selectAllHashtag():
    rows=Hashtag.query.all()
    return render_template("hashtag.html", rows=rows)

@app.route('/hashtag/insert', methods=['POST'])
def insertHashtag():
    hashtag = request.form['hashtag']
    new_data = Hashtag(hashtag=hashtag)
    db.session.add(new_data)
    db.session.commit()
    return json.dumps({"status":1})
    
@app.route('/hashtag/delete', methods=['POST'])
def deleteHashtag():
    id = request.form['id']
    hashtag = Hashtag.query.get(id)
    db.session.delete(hashtag)
    db.session.commit()
    return json.dumps({"status":1})


